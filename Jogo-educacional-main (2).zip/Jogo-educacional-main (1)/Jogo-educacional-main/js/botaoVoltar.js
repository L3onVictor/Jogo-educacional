function voltarMenu() {
    window.location.href = '../index.html';
}